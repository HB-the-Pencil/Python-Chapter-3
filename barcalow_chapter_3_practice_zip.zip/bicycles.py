# I don't know much about bikes :P
bicycles = ["trek", "cannondale", "redline", "specialized"]
print(bicycles[0].title())
# Interestingly, Python automatically prints the strings with single quotes (if you print the whole list).
message = f"The item at index -1 (a {bicycles[-1].title()}) is the same as the item at the index len(bicycles)-1 (a {bicycles[len(bicycles)-1].title()})."
print(message)
message = f"Once, I owned a {bicycles[2].title()}..."
print(message)