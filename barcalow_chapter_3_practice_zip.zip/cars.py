# Some of my favorites.
cars = ["BMW", "MINI", "Honda", "Ford", "Toyota"]
cars.sort()
print(cars)
# THAT'S SO COOL!!

cars.sort(reverse=True)
print(cars)

# what happens if I...?
print(cars.sort())  # returns "None". Hmmm....

print("************************************")

# Reset the list.
cars = ["BMW", "MINI", "Honda", "Ford", "Toyota"]

print(f"Sorted: {sorted(cars)}")

print(f"Unsorted: {cars}")

print(f"Reverse sorted: {sorted(cars, reverse=True)}")

# Evidently capital letters can be interpreted multiple ways... I wonder what makes them different?

print("************************************")

# Reset the list again.
cars = ["BMW", "MINI", "Honda", "Ford", "Toyota"]

cars.reverse()
print(cars)
# So, in theory, to get a backwards alphabetical list, you could just .sort().reverse() it.

cars.sort()
cars.reverse()
print(cars)
# Yes, it does work.

print("************************************")

# Reset the list again.
cars = ["BMW", "MINI", "Honda", "Ford", "Toyota"]

print(len(cars))
# I used len() earlier... It was for bicycles.py to prove that index -1 is the same as index len(list)-1.