# I know slightly more about motorcycles than I do about bikes
motorcycles = ["Yamaha", "Suzuki", "Honda"]
# but only slightly more

print(motorcycles)

# Add a new item to motorcycles
motorcycles.append("Ducati")

# and then print the new list.
print(motorcycles)

print("************************************")

# Let's create a blank list and see if we can append items
# until it says the same thing as the old list.
motorcycles = []

motorcycles.append("Yamaha")
motorcycles.append("Suzuki")
motorcycles.append("Honda")
print(motorcycles)

# It looks the same!
# PyCharm doesn't like me declaring the list over 5 lines though :P

print("************************************")

# del motorcycles[1]
# print(motorcycles)
# Interesting... in JavaScript, deleting a value leaves an undefined hole at that index.

popped_motorcycle = motorcycles.pop()
# Maybe it's popping a wheelie lol
print(motorcycles)
print(popped_motorcycle)

motorcycles.remove("Yamaha")  # I was curious and learned that if the item is not in the list, it throws
print(motorcycles)            # an error. Process finishes with exit code 1.

print(motorcycles[3])  # an error here too. Index out of range. (If I put a 1, it throws at the start; if
                       # I put a 2 or greater, it throws at the end. Weird.)

                       # It's not doing it anymore!! Python is so strange.

# Remember: pop if you want to be able to use it, del if you want to erase it, remove if you only know the value.